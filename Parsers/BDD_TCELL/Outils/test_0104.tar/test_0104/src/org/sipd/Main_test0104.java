package org.sipd;

import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.inria.database.QEPng;
import test.jdbc.Tools;


public class Main_test0104 extends Tools {

	public static void main(String argv[])
	{
		Main_test0104 projet = new Main_test0104();
		projet.out = new PrintWriter(java.lang.System.out);
		String dbmsHost = null;
		java.sql.PreparedStatement ps;
		int res;
		int idGlobal=0;
		int version=0;
		
		if (argv.length == 1)
		{
			dbmsHost = argv[0];
		}
		else
		{
			projet.out.println("Missing argument: e.g. COM3, /dev/ttyACM0, ...");
			if (projet.out != null)
				projet.out.close();
			return;	    	
		}

		// this not a performance test ==> output is produced:
		perf = 0;
		
		try {
			// initialize the driver:
			projet.init();

			// connect without authentication
			projet.openConnection(dbmsHost, null);

			//ATTENTION : pas obligatoire mais préférable si l'éxécution du programme sur le token se termine brutalement			
		    projet.Desinstall_DBMS_MetaData();
		    
			// load the DB schema
			String schema = Schema.META;

			// load the DB schema
			projet.Install_DBMS_MetaData(schema.getBytes(), 0);
			
			// load and install QEPs
			Class<?>[] executionPlans = new Class[] { QEP.class };
			QEPng.loadExecutionPlans( QEP_IDs.class, executionPlans );
			QEPng.installExecutionPlans( projet.db );

			//Insertion Websites 1 & 2
			ps = ((org.inria.jdbc.Connection)projet.db).prepareStatement(QEP_IDs.EP_Project.EP_AJOUTSITE);
			//ATTENTION : tous les IdGlobal doivent commencer à 1 (cf Utilisation de PlugDBcomm)
			ps.setInt(1, 1); 
			ps.setString(2, "FieldLoginSite1");
			ps.setString(3, "FieldPassSite1"); 
			ps.setString(4, "http://www.site1.fr/form.php"); 
			ps.setInt(5, 0); 
			res = ps.executeUpdate();
			if(res==0)
				System.out.println("fail ajout site 1.");
			
			ps.setInt(1, 2); 
			ps.setString(2, "FieldLSite2");
			ps.setString(3, "FieldPSite2"); 
			ps.setString(4, "http://www.site2.com/formulaire.php"); 
			ps.setInt(5, 0); 
			res = ps.executeUpdate();
			if(res==0)
				System.out.println("fail ajout site 2.");

		    //Affichage Website1 originel (On se sert de PREMODIFFORM pour afficher les valeurs d'un site dans ce programme de test)
			ps = ((org.inria.jdbc.Connection)projet.db).prepareStatement(QEP_IDs.EP_Project.EP_PREMODIFFORM);
			ps.setString(1, "http://www.site1.fr/form.php");
			org.inria.jdbc.ResultSet resultSet= (org.inria.jdbc.ResultSet) ps.executeQuery();
			System.out.println("\nEXECUTING QUERY NUMBER 1 (Affichage Website1 originel) ...");
			while (resultSet.next()) 
			{
				//ATTENTION, getString(1) peut poser des problèmes ... (Je ne sais pas s'il faut garder getString(1) lorsque le SELECT doit retourner un tuple composé de plusieurs valeurs)
				System.out.println(resultSet.getInt(1));
				System.out.println(resultSet.getString(2));
				System.out.println(resultSet.getString(3));
				System.out.println(resultSet.getInt(4));
				
			}
			System.out.println("DONE\n");

		
	    	//Modification Website 1 
			ps = ((org.inria.jdbc.Connection)projet.db).prepareStatement(QEP_IDs.EP_Project.EP_PREMODIFFORM);
			ps.setString(1, "http://www.site1.fr/form.php");
			org.inria.jdbc.ResultSet resultSet5 = (org.inria.jdbc.ResultSet) ps.executeQuery();
			System.out.println("Pre_modifform...");
			while(resultSet5.next())
			{
				idGlobal = resultSet5.getInt(1);
				version = resultSet5.getInt(4);
				System.out.println("IdGlobal = "+ idGlobal);
				System.out.println("Version = "+ version);
			}
			
			ps = ((org.inria.jdbc.Connection)projet.db).prepareStatement(QEP_IDs.EP_Project.EP_MODIFFORMDELETE);
			ps.setInt(1, 1);
			ps.executeUpdate();
			System.out.println("Delete...");
			
			ps = ((org.inria.jdbc.Connection)projet.db).prepareStatement(QEP_IDs.EP_Project.EP_MODIFFORM);
			version+=1;
			ps.setInt(1, idGlobal);
			ps.setString(2, "New_FieldLoginSite1");
			ps.setString(3, "New_FielPasswordSite1");
			ps.setString(4, "http://www.site1.fr/form.php");
			ps.setInt(5, version);
			ps.executeUpdate();
			System.out.println("Modifform...");

			System.out.println("\nEXECUTING QUERY NUMBER 2 (Modification Website 1) ...");

		    System.out.println("DONE\n");

		    //Affichage Website1 modifié (On se sert de PREMODIFFORM pour afficher les valeurs d'un site dans ce programme de test)
			ps = ((org.inria.jdbc.Connection)projet.db).prepareStatement(QEP_IDs.EP_Project.EP_PREMODIFFORM);
			ps.setString(1, "http://www.site1.fr/form.php");
			org.inria.jdbc.ResultSet resultSet2 = (org.inria.jdbc.ResultSet) ps.executeQuery();
			
			System.out.println("\nEXECUTING QUERY NUMBER 3 (Affichage Website1 modifié) ...");
			while (resultSet2.next()) 
			{
				System.out.println(resultSet2.getInt(1));
				System.out.println(resultSet2.getString(2));
				System.out.println(resultSet2.getString(3));
				System.out.println(resultSet2.getInt(4));
			}
		
		    System.out.println("DONE\n");

		    /*
		    TODO : IL FAUDRAIT ESSAYER DE "PARSER" LES DONNEES QU'ON RECOIT DANS LE RESULTSET PRECEDENT ET LES METTRE DANS DIFFERENTES VARIABLES
		    */

		    //Ajout de User1 et User2 
			ps = ((org.inria.jdbc.Connection)projet.db).prepareStatement(QEP_IDs.EP_Project.EP_INSCRIPTION);
			ps.setInt(1, 1);
			ps.setString(2, "User1");
			ps.setString(3, "azerty");
			ps.setString(4, "Finger1");
			ps.setString(5, "BackupKey1");
			ps.setInt(6, 0);
			ps.executeUpdate();

			ps.setInt(1, 2);
			ps.setString(2, "User2");
			ps.setString(3, "qwerty");
			ps.setString(4, "Finger2");
			ps.setString(5, "BackupKey2");
			ps.setInt(6, 0);
			ps.executeUpdate();	

			//Affichage des utilisateurs disponibles dans la BDD (On se sert de PREINSCRIPTION pour afficher tous les IdGlobal des utilisateurs)
			ps = ((org.inria.jdbc.Connection)projet.db).prepareStatement(QEP_IDs.EP_Project.EP_PREINSCRIPTION);
			org.inria.jdbc.ResultSet resultSet3 = (org.inria.jdbc.ResultSet) ps.executeQuery();
			
			System.out.println("\nEXECUTING QUERY NUMBER 4 (Affichage des utilisateurs disponibles dans la BDD) ...");
			while (resultSet3.next()) 
			{
				//ATTENTION, getString(1) peut poser des problèmes ... (Je ne sais pas s'il faut garder getString(1) lorsque le SELECT doit retourner un int)
				System.out.println(resultSet3.getInt(1)/*.getString(1)*/);
			}
		
		    System.out.println("DONE\n");

		    //Suppression de User2 (On cherche a savoir si l'execution d'une requête de type DELETE ne plante pas)
			ps = ((org.inria.jdbc.Connection)projet.db).prepareStatement(QEP_IDs.EP_Project.EP_SUPPRUSER_USER);
			ps.setInt(1,2);
			//org.inria.jdbc.ResultSet resultSet= (org.inria.jdbc.ResultSet) ps.executeQuery();
			System.out.println("\nEXECUTING QUERY NUMBER 5 (Suppression de User2) ...");

			//ATTENTION : on utilise executeUpdate au lieu de executeQuery car on cherche à faire un DELETE et non pas un SELECT (cf Utilisation de PlugDBcomm)
			ps.executeUpdate();

		    System.out.println("DONE\n");

			//Affichage des utilisateurs disponibles dans la BDD (On se sert de PREINSCRIPTION pour afficher tous les IdGlobal des utilisateurs)
			ps = ((org.inria.jdbc.Connection)projet.db).prepareStatement(QEP_IDs.EP_Project.EP_PREINSCRIPTION);
			org.inria.jdbc.ResultSet resultSet4 = (org.inria.jdbc.ResultSet) ps.executeQuery();
			
			System.out.println("\nEXECUTING QUERY NUMBER 4 (Affichage des utilisateurs disponibles dans la BDD) ...");
			while (resultSet4.next()) 
			{
				//ATTENTION, getString(1) peut poser des problèmes ... (Je ne sais pas s'il faut garder getString(1) lorsque le SELECT doit retourner un int)
				System.out.println(resultSet4.getInt(1));
			}
		
		    System.out.println("DONE\n");

		    projet.Desinstall_DBMS_MetaData();

			projet.Shutdown_DBMS();

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		finally
		{
			if (projet.out != null)
			{
				projet.out.close();
			}
		}
	}
}